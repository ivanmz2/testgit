import boto3
import json

def handler(event, context):
    print(event)
    sns_client = boto3.client("sns")
    # remember to change this
    sns_arn = "arn:aws:sns:ca-central-1:690521436457:fanout" 

    for record in event["Records"]:
        product = json.loads(record["body"])
        print(product)

    try:
        sns_client.publish(
            TopicArn=sns_arn,
            Subject=f"Order {product['id']} was placed",
            Message=record["body"]
            )

        print("successfully sent notification")
    except Exception as exp:
        print(f"error occured, {exp}")