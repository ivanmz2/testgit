import uuid

printf("Hello World")
